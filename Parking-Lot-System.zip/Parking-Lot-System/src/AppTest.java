package slots.parking.txstate.edu;

import java.io.File;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
        
        File file=new File("map");
        if(file.exists())
        	file.delete();
        
        Slots.initMap();
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testSlotCheckin_Checkout_car()
    {
    	String slotNo="121";
    	String vNo="V001";
        assertTrue( Slots.slotCheckin(slotNo, vNo,"CAR"));
        assertTrue( Slots.checkOut(vNo) );
    }
    public void testSlotCheckout_car_notCheckdIn()
    {
    	String vNo="V001";
        assertFalse(Slots.checkOut(vNo) );
    }
    public void testBookedSlot_Checkin() {
    	String slotNo="122";
    	String vNo="V002";
        assertTrue( Slots.slotCheckin(slotNo, vNo,"CAR") );
        assertFalse( Slots.slotCheckin(slotNo, vNo,"CAR") );
    }
    public void testDuplicateVehicleCheckin() {
    	String slotNo="123";
    	String vNo="V003";
    	assertTrue( Slots.slotCheckin(slotNo, vNo,"CAR") );
    	slotNo="124";
        assertFalse( Slots.slotCheckin(slotNo, vNo,"CAR") );
    }
    public void testAvailableSlots_Car() {
    	int countCar=Slots.getAvailableSlot("CAR");
    	String slotNo="125";
    	String vNo="V005";
    	assertTrue( Slots.slotCheckin(slotNo, vNo,"CAR") );
    	slotNo="126";
    	vNo="V006";
    	assertTrue( Slots.slotCheckin(slotNo, vNo,"CAR") );
        assertEquals((countCar-2), Slots.getAvailableSlot("CAR"));
    }
}
